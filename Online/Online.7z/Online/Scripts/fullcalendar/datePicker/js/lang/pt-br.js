var fdLocale = {
fullMonths:["Janeiro", "Fevereiro", "Mar\u00E7o", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"],
monthAbbrs:["Jan", "Fev", "Mar", "Abr", "Maio", "Jun", "Jul", "Ago", "Set", "Out", "Nov", "Dez"],
fullDays:["Segunda\u002DFeira", "Ter\u00E7a\u002DFeira", "Quarta\u002DFeira", "Quinta\u002DFeira", "Sexta\u002DFeira", "S\u00E1bado", "Domingo"],
dayAbbrs:["Seg", "Ter", "Qua", "Qui", "Sex", "Sab", "Dom"],
titles:["M\u00EAs Anterior", "Pr\u00F3ximo M\u00EAs", "Ano Anterior", "Pr\u00F3ximo Ano", "Hoje", "Exibir Calend\u00E1rio", "Sem", "Semana [[%0%]] de [[%1%]]", "Semana", "Selecione uma Data", "Clique e Arraste para Mover", "Exibir \u0022[[%0%]]\u0022 primeiro", "Ir para Data de Hoje", "Data Desabilitada"]};
try { 
        if("datePickerController" in window) { 
                datePickerController.loadLanguage(); 
        }; 
} catch(err) {};