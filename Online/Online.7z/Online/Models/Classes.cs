﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online.Models
{
    public class gw_Result
    {
        public string xmloutput;
        public int success; 
        public string message;
        public string reference;

    }
    public class FileClass
    {
        public string fieldname;
        public string name;
        public string url;

    }

}