﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Online.Models
{
    public class FileClassX
    {
        public string repeater;
        public string fieldname;
        public string url;

    }
}