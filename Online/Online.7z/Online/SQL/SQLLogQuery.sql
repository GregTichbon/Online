﻿USE [OnlineApplications]
GO
/****** Object:  StoredProcedure [dbo].[SQLLogQuery]    Script Date: 09/29/2016 10:40:17 ******/
SET ANSI_NULLS OFF
GO
SET QUOTED_IDENTIFIER OFF
GO


/*

SQLLogQuery 'NZPostAddressSearch'

*/

ALTER PROCEDURE [dbo].[SQLLogQuery]
	@sqllog_ctr bigint = null,
	@sqlID varchar(100) = null,
	@fromdate varchar(11) = null,
	@todate varchar(11) = null
as

	declare @sql as varchar(2000)
	
	if isnull(@fromdate ,'') = '' 
		set @fromdate = cast(getdate() as varchar(11))
		
	if isnull(@todate ,'') = '' 
		set @todate = cast(getdate() as varchar(11))

	
	set @sql = 
	
		'select L.SQLLog_ctr, L.SQLID, L.DateTime, L.ErrorMessage, L.Information, P.ParamName, P.ParamDefinition, 
		''value'' = case when p.ParamType = ''Text'' then p.TextVal when p.ParamType = ''Number'' then cast(p.NumberVal as varchar(1000)) when p.ParamType = ''XML''  then cast(p.xmlVal as varchar(Max)) else ''Invalid Type'' end,
		case when p.ParamType = ''Text'' then len(p.TextVal) else ''0'' end as ''Length''
		 from SQLLog L
		left outer join SQLLogParam P on P.SQLLog_CTR = L.SQLLog_CTR
		where datetime between ''' + @fromdate + ''' and ''' + @todate + '  23:59:59'''
	
	if isnull(@sqlID ,'') <> ''
		set @sql = @sql + ' and L.SQLID = ''' + @sqlID + ''''
		
	if isnull(@sqllog_ctr ,0) <> 0
		set @sql = @sql + ' and L.sqllog_ctr = ' + cast(@sqllog_ctr as varchar(20))
		
	set @sql = @sql + ' order by L.SQLLog_CTR, P.SQLLogParam_CTR'

	--select @sql
	
	exec (@sql)

